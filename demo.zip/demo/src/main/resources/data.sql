INSERT INTO DYNAMIC_ROUTE (predicate, filter, uri) VALUES ('/api/service1/**', 'StripPrefix=1', 'http://localhost:8081');
INSERT INTO DYNAMIC_ROUTE (predicate, filter, uri) VALUES ('/api/service2/**', 'RewritePath=/api/service2/(?<segment>.*),/newService2/$\\{segment}', 'http://localhost:8082');
INSERT INTO DYNAMIC_ROUTE (predicate, filter, uri) VALUES ('/api/service3/**', 'StripPrefix=1', 'http://localhost:8083');

INSERT INTO ROUTE_DETAIL (store, datastore, dynamic_route_id) VALUES ('store1', 'datastore1', 1);
INSERT INTO ROUTE_DETAIL (store, datastore, dynamic_route_id) VALUES ('store1', 'datastore1', 2);
INSERT INTO ROUTE_DETAIL (store, datastore, dynamic_route_id) VALUES ('store1', 'datastore1', 3);
