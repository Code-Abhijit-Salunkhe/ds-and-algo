/*CREATE TABLE DYNAMIC_ROUTE (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      predicate VARCHAR(255),
      filter VARCHAR(255),
      uri VARCHAR(255),
      store VARCHAR(255),
      datastore VARCHAR(255)
);
*/

CREATE TABLE /*IF NOT EXISTS*/ DYNAMIC_ROUTE (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    predicate VARCHAR(255),
    filter VARCHAR(255),
    uri VARCHAR(255)
);

CREATE TABLE /*IF NOT EXISTS*/ ROUTE_DETAIL (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    store VARCHAR(255),
    datastore VARCHAR(255),
    dynamic_route_id BIGINT,
    FOREIGN KEY (dynamic_route_id) REFERENCES DYNAMIC_ROUTE(id)
);

