package com.example.demo.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@SqlResultSetMapping(
        name = "DynamicRouteMapping",
        entities = {
                @EntityResult(
                        entityClass = DynamicRoute.class,
                        fields = {
                                @FieldResult(name = "id", column = "id"),
                                @FieldResult(name = "predicate", column = "predicate"),
                                @FieldResult(name = "filter", column = "filter"),
                                @FieldResult(name = "uri", column = "uri"),
                                @FieldResult(name = "store", column = "store"),
                                @FieldResult(name = "datastore", column = "datastore")
                        }
                )
        }
)
@NamedNativeQuery(
        name = "DynamicRoute.findAllWithDetails",
        query = "SELECT dr.id, dr.predicate, dr.filter, dr.uri, rd.store, rd.datastore " +
                "FROM DYNAMIC_ROUTE dr " +
                "JOIN ROUTE_DETAIL rd ON dr.id = rd.dynamic_route_id " +
                "WHERE rd.store = :store AND rd.datastore = :datastore",
        resultSetMapping = "DynamicRouteMapping"
)
public class DynamicRoute {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String predicate;
    private String filter;
    private String uri;
    private String store;
    private String datastore;

    // Getters and Setters
}
