package com.example.demo.config;

import com.example.demo.entity.DynamicRoute;
import com.example.demo.filter.CustomLoggingFilter;
import com.example.demo.service.DynamicRouteService;
import lombok.AllArgsConstructor;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
@AllArgsConstructor
public class GatewayConfig {


    private final DynamicRouteService dynamicRouteService;

    private final CustomLoggingFilter customLoggingFilter;

    @Bean
/*    @DependsOn("initDatabase")*/
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
        // Example predicate to match routes
        String store = "store1";

        String dataSource = "datastore1";
        List<DynamicRoute> routes = dynamicRouteService.getDynamicRoutes(store, dataSource);

        RouteLocatorBuilder.Builder routesBuilder = builder.routes();

        routes.forEach(route -> {
            String uri = route.getUri();
            String predicate = route.getPredicate();
            String filter = route.getFilter();

            routesBuilder.route(r -> r.path(predicate)
                    .filters(f -> f.filter(customLoggingFilter))
                    .uri(uri));
        });

        return routesBuilder.build();
    }


  /*  @Bean(name = "initDatabase")
    CommandLineRunner initDatabase(DynamicRouteRepository repository, JdbcTemplate jdbcTemplate) {
        return args -> {
            // Create the DynamicRoute table
            jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS DYNAMIC_ROUTE (" +
                    "id BIGINT AUTO_INCREMENT PRIMARY KEY," +
                    "predicate VARCHAR(255)," +
                    "filter VARCHAR(255)," +
                    "uri VARCHAR(255)," +
                    "store VARCHAR(255)," +
                    "datastore VARCHAR(255)" +
                    ")");

            // Insert initial data
            repository.save(new DynamicRoute(null, "/api/service1/**", "StripPrefix=1", "http://localhost:8081", "store1", "datastore1"));
            repository.save(new DynamicRoute(null, "/api/service2/**", "RewritePath=/api/service2/(?<segment>.*),/newService2/$\\{segment}", "http://localhost:8082", "store2", "datastore2"));
            repository.save(new DynamicRoute(null, "/api/service3/**", "StripPrefix=1", "http://localhost:8083", "store3", "datastore3"));
        };
    }*/
}

