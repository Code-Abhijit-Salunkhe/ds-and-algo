package com.example.demo.service;

import com.example.demo.entity.DynamicRoute;
import com.example.demo.repository.DynamicRouteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DynamicRouteService {

    @Autowired
    private DynamicRouteRepository dynamicRouteRepository;

    public List<DynamicRoute> getDynamicRoutes(String store, String dataStore) {
        return dynamicRouteRepository.findDynamicRoutes(store, dataStore);
    }
}

